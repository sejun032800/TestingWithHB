from pynput.mouse import Button, Controller as MouseController

mouse = MouseController()

while True:
    print(mouse.position)